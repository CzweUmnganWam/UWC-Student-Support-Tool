const requiredColumns = [
  "learnerId", "ageBand", "province", "deviceAccess", "internetAccess",
  "digitalConfidence", "programmingConfidence", "aiFamiliarity", "employmentStatus",
  "supportNeed", "attendanceRisk", "notes"
];

let learners = [];
let charts = {};

const sampleLearners = [
  ["L001","18-24","Western Cape","Laptop","Reliable",4,3,2,"Unemployed","Mentoring","Low","Needs career guidance"],
  ["L002","25-29","Gauteng","Phone only","Limited",2,1,1,"Unemployed","Data","High","No laptop at home"],
  ["L003","18-24","KZN","Shared laptop","Unstable",3,2,2,"Under-employed","Academic support","Medium","Works evenings"],
  ["L004","30-35","Eastern Cape","Phone only","Limited",1,1,1,"Unemployed","Transport","High","Long commute"],
  ["L005","25-29","Western Cape","Laptop","Reliable",5,4,3,"Employed part-time","Mentoring","Low","Strong motivation"],
  ["L006","18-24","Limpopo","Shared laptop","Unstable",2,2,2,"Unemployed","Data","Medium","Needs practice time"],
  ["L007","30-35","Gauteng","Laptop","Reliable",4,3,4,"Under-employed","Mentoring","Low","Interested in AI"],
  ["L008","25-29","KZN","Phone only","Limited",2,1,2,"Unemployed","Academic support","High","Missed orientation"],
  ["L009","18-24","Northern Cape","Shared laptop","Unstable",3,2,1,"Unemployed","Transport","Medium","Far from training site"],
  ["L010","36+","Western Cape","Laptop","Reliable",4,2,3,"Employed part-time","Academic support","Medium","Needs coding support"],
  ["L011","25-29","Mpumalanga","Phone only","Limited",1,1,1,"Unemployed","Data","High","Needs device support"],
  ["L012","18-24","Free State","Shared laptop","Unstable",3,3,2,"Under-employed","Mentoring","Low","Peer mentor helpful"]
].map(row => objectFromRow(row));

function objectFromRow(row) {
  return Object.fromEntries(requiredColumns.map((col, i) => [col, row[i] ?? ""]));
}

function normaliseLearner(raw) {
  return {
    learnerId: String(raw.learnerId || "").trim(),
    ageBand: String(raw.ageBand || "").trim(),
    province: String(raw.province || "").trim(),
    deviceAccess: String(raw.deviceAccess || "").trim(),
    internetAccess: String(raw.internetAccess || "").trim(),
    digitalConfidence: Number(raw.digitalConfidence),
    programmingConfidence: Number(raw.programmingConfidence),
    aiFamiliarity: Number(raw.aiFamiliarity),
    employmentStatus: String(raw.employmentStatus || "").trim(),
    supportNeed: String(raw.supportNeed || "").trim(),
    attendanceRisk: String(raw.attendanceRisk || "").trim(),
    notes: String(raw.notes || "").trim()
  };
}

function splitCSVLine(line) {
  const cells = [];
  let current = "";
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    if (char === '"' && line[i + 1] === '"') { current += '"'; i++; }
    else if (char === '"') inQuotes = !inQuotes;
    else if (char === "," && !inQuotes) { cells.push(current.trim()); current = ""; }
    else current += char;
  }
  cells.push(current.trim());
  return cells;
}

function parseCSV(text) {
  const rows = text.trim().split(/\r?\n/).filter(Boolean).map(splitCSVLine);
  const headers = rows.shift().map(h => h.trim());
  return rows.map(row => {
    const item = {};
    headers.forEach((header, index) => item[header] = row[index] || "");
    return normaliseLearner(item);
  });
}

function validateData(data) {
  const messages = [];
  const ids = data.map(x => x.learnerId);
  const duplicates = ids.filter((id, index) => id && ids.indexOf(id) !== index);
  const missingRows = data.filter(x => requiredColumns.some(col => col !== "notes" && !x[col])).length;
  const invalidScores = data.filter(x => [x.digitalConfidence, x.programmingConfidence, x.aiFamiliarity].some(score => score < 1 || score > 5 || Number.isNaN(score))).length;

  messages.push({ type: data.length ? "ok" : "warn", text: `${data.length} learner record(s) loaded.` });
  messages.push({ type: missingRows ? "bad" : "ok", text: `${missingRows} row(s) have missing required values.` });
  messages.push({ type: duplicates.length ? "bad" : "ok", text: `${new Set(duplicates).size} duplicate learner ID(s) found.` });
  messages.push({ type: invalidScores ? "bad" : "ok", text: `${invalidScores} row(s) have invalid confidence scores. Scores must be 1 to 5.` });
  return messages;
}

function riskScore(learner) {
  let score = 0;
  if (learner.attendanceRisk.toLowerCase() === "high") score += 3;
  if (learner.attendanceRisk.toLowerCase() === "medium") score += 1.5;
  if (learner.deviceAccess.toLowerCase().includes("phone")) score += 2;
  if (["limited", "unstable"].includes(learner.internetAccess.toLowerCase())) score += 2;
  if (learner.digitalConfidence <= 2) score += 1;
  if (learner.programmingConfidence <= 2) score += 1;
  if (learner.aiFamiliarity <= 2) score += 0.5;
  return score;
}

function riskFlag(score) {
  if (score >= 6) return "High support priority";
  if (score >= 3) return "Medium support priority";
  return "Low support priority";
}

function countBy(field) {
  return learners.reduce((acc, learner) => {
    acc[learner[field]] = (acc[learner[field]] || 0) + 1;
    return acc;
  }, {});
}

function average(field) {
  if (!learners.length) return 0;
  return learners.reduce((sum, x) => sum + Number(x[field] || 0), 0) / learners.length;
}

function drawChart(id, type, labels, data, label) {
  const canvas = document.getElementById(id);
  if (!canvas) return;
  if (charts[id]) charts[id].destroy();
  const palette = ["#003f7d", "#0072bc", "#f4c542", "#0b2d5c", "#16a34a", "#ef4444", "#6b8bbd"];
  charts[id] = new Chart(canvas, {
    type,
    data: {
      labels,
      datasets: [{
        label,
        data,
        borderWidth: 2,
        borderColor: type === "bar" ? "rgba(0,63,125,.88)" : "#ffffff",
        backgroundColor: type === "bar" ? "rgba(0,114,188,.78)" : palette,
        borderRadius: type === "bar" ? 12 : 0
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { display: type !== "bar", labels: { usePointStyle: true, boxWidth: 8 } } },
      scales: type === "bar" ? { y: { beginAtZero: true, ticks: { precision: 0 } }, x: { grid: { display: false } } } : undefined
    }
  });
}

function updateDashboard() {
  learners = learners.map(normaliseLearner);
  const risks = learners.map(riskScore);
  const highRisk = risks.filter(score => score >= 6).length;
  const supportCounts = countBy("supportNeed");
  const topSupport = Object.entries(supportCounts).sort((a, b) => b[1] - a[1])[0]?.[0] || "None";
  const readiness = learners.length ? Math.max(0, Math.min(100, Math.round(100 - (highRisk / learners.length) * 100))) : 0;

  document.getElementById("totalLearners").textContent = learners.length;
  document.getElementById("highRiskCount").textContent = highRisk;
  document.getElementById("avgDigital").textContent = average("digitalConfidence").toFixed(1);
  document.getElementById("topNeed").textContent = topSupport;
  document.getElementById("readinessScore").textContent = `${readiness}%`;
  document.getElementById("readinessBar").style.width = `${readiness}%`;
  document.getElementById("readinessText").textContent = learners.length
    ? `${learners.length - highRisk} learners currently appear lower risk. Review high-priority cases manually.`
    : "Load data to calculate readiness.";

  renderValidation();
  renderRecommendations(supportCounts, highRisk);
  renderTable();
  renderCharts();
}

function renderValidation() {
  const list = document.getElementById("validationList");
  list.innerHTML = "";
  validateData(learners).forEach(message => {
    const li = document.createElement("li");
    li.className = message.type;
    li.textContent = message.text;
    list.appendChild(li);
  });
}

function renderRecommendations(supportCounts, highRisk) {
  const recommendations = [];
  if ((supportCounts.Data || 0) > 0) recommendations.push("Provide data bundles or campus Wi-Fi access for learners with limited or unstable internet.");
  if ((supportCounts["Academic support"] || 0) > 0) recommendations.push("Schedule weekly coding clinics for learners with low programming confidence.");
  if (highRisk > 0) recommendations.push("Assign staff follow-ups for high-priority learners before attendance issues escalate.");
  if ((supportCounts.Transport || 0) > 0) recommendations.push("Review transport barriers and consider travel support or hybrid attendance options.");
  if ((supportCounts.Mentoring || 0) > 0) recommendations.push("Create a peer-mentoring group to improve learner confidence and belonging.");
  if (!recommendations.length) recommendations.push("Load learner data to generate recommendations.");

  document.getElementById("recommendations").innerHTML = recommendations.slice(0, 5).map(item => `<li>${item}</li>`).join("");
}

function renderTable() {
  const query = (document.getElementById("searchInput")?.value || "").toLowerCase();
  const filtered = learners.filter(learner => Object.values(learner).join(" ").toLowerCase().includes(query));
  document.getElementById("learnerTable").innerHTML = filtered.map(learner => {
    const score = riskScore(learner);
    const flag = riskFlag(score);
    const className = flag.startsWith("High") ? "high" : flag.startsWith("Medium") ? "medium" : "low";
    return `
      <tr>
        <td>${learner.learnerId}</td>
        <td>${learner.province}</td>
        <td>${learner.supportNeed}</td>
        <td>${learner.attendanceRisk}</td>
        <td>${score.toFixed(1)}</td>
        <td><span class="badge ${className}">${flag}</span></td>
      </tr>`;
  }).join("") || `<tr><td colspan="6">No learners found. Upload a CSV or load demo data.</td></tr>`;
}

function renderCharts() {
  const support = countBy("supportNeed");
  const risk = countBy("attendanceRisk");
  const device = countBy("deviceAccess");

  drawChart("supportChart", "bar", Object.keys(support), Object.values(support), "Learners");
  drawChart("riskChart", "doughnut", Object.keys(risk), Object.values(risk), "Learners");
  drawChart("deviceChart", "pie", Object.keys(device), Object.values(device), "Learners");
  drawChart("confidenceChart", "bar", ["Digital", "Programming", "AI familiarity"], [average("digitalConfidence"), average("programmingConfidence"), average("aiFamiliarity")], "Average score");
}

function downloadReport() {
  const highRiskRows = learners.filter(x => riskScore(x) >= 6).map(x => x.learnerId).join(", ") || "None";
  const text = `Student Support Insights Summary\n\nTotal learners: ${learners.length}\nHigh-risk learners: ${highRiskRows}\nAverage digital confidence: ${average("digitalConfidence").toFixed(1)}\nAverage programming confidence: ${average("programmingConfidence").toFixed(1)}\nAverage AI familiarity: ${average("aiFamiliarity").toFixed(1)}\n\nResponsible use: Risk flags are support indicators only and require human review.`;
  const blob = new Blob([text], { type: "text/plain" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = "student-support-summary.txt";
  link.click();
}

document.getElementById("loadSampleBtn").addEventListener("click", () => { learners = [...sampleLearners]; updateDashboard(); });
document.getElementById("clearBtn").addEventListener("click", () => { learners = []; updateDashboard(); });
document.getElementById("downloadBtn").addEventListener("click", downloadReport);

function handleCSVFile(file) {
  if (!file) return;
  const reader = new FileReader();
  reader.onload = e => { learners = parseCSV(e.target.result); updateDashboard(); };
  reader.readAsText(file);
}

document.getElementById("csvFile").addEventListener("change", event => handleCSVFile(event.target.files[0]));

const dropZone = document.getElementById("dropZone");
["dragenter", "dragover"].forEach(name => dropZone.addEventListener(name, event => {
  event.preventDefault();
  dropZone.classList.add("dragover");
}));
["dragleave", "drop"].forEach(name => dropZone.addEventListener(name, event => {
  event.preventDefault();
  dropZone.classList.remove("dragover");
}));
dropZone.addEventListener("drop", event => handleCSVFile(event.dataTransfer.files[0]));
document.getElementById("searchInput").addEventListener("input", renderTable);

document.getElementById("learnerForm").addEventListener("submit", event => {
  event.preventDefault();
  const formData = new FormData(event.target);
  learners.push(normaliseLearner(Object.fromEntries(formData.entries())));
  event.target.reset();
  updateDashboard();
});

updateDashboard();
